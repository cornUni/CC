GRAPH = {
    "A": {"Distance": 0, "AdjacencyList": {"B":10,"C":5}},
    "B": {"Distance": float('inf'), "AdjacencyList": {"C":2,"D":1}},
    "C": {"Distance": float('inf'), "AdjacencyList": {"E":2,"B":3,"D":9}},
    "D": {"Distance": float('inf'), "AdjacencyList": {"E":4}},
    "E": {"Distance": float('inf'), "AdjacencyList": {"A":7,"D":6}}
}
#!/bin/bash

# This actully yarn to manage resource cluster
$HADOOP_HOME/bin/yarn --config $HADOOP_CONF_DIR resourcemanager
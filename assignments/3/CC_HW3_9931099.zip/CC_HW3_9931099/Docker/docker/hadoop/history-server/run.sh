#!/bin/bash

# Kick-off yarn server
$HADOOP_HOME/bin/yarn --config $HADOOP_CONF_DIR historyserver
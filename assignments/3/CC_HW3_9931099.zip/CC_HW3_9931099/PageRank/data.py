graph = {
    "A": {"PageRank": 1.0, "AdjacencyList": ["B", "C"]},
    "B": {"PageRank": 0.5, "AdjacencyList": ["A"]},
    "C": {"PageRank": 0.5, "AdjacencyList": []}
}